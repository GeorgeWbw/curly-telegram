import torch
import torch.nn as nn
import torch.nn.functional as F
import random
from collections import namedtuple, deque


Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward'))

device = "cuda" if torch.cuda.is_available() else "cpu"

epochs = 100
batch_size = 128
learning_rate = 1e-3
gamma = 0.9
class Q_network(nn.Module):
    def __init__(self):
        super(Q_network, self).__init__()
        self.fc1 = nn.Linear(15,1024)
        self.fc2 = nn.Linear(1024,128)
        self.fc3 = nn.Linear(128,6)
        
        
        
    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = F.relu(self.fc2(x))
        x = self.fc3(x)
        return x

        
#optimizer = torch.optim.RMSprop(model.parameters(), lr=learning_rate)  
#loss_fn   = nn.MSELoss()


def give_action(model, state):
    state = torch.tensor(state, device=device, dtype=torch.float32).reshape(1,-1)
    return model(state).max(1)[1].view(1,1).item()
    
    
def train_step(model, target_model, transitions):  

    optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate) #RMPpros seems not good
    loss_fn   = nn.SmoothL1Loss()
    
    samples = random.sample(transitions, batch_size)
    batch   = Transition(*zip(*samples))
    
    non_final_mask = torch.tensor(tuple(map(lambda s: s is not None,
                                          batch.next_state)), device=device, dtype=torch.bool)
    #print(non_final_mask)                           
    non_final_next_states = torch.tensor([s for s in batch.next_state
                                                if s is not None], device=device, dtype=torch.float32)
    
    state_batch = torch.tensor(batch.state, dtype=torch.float32, device=device)

    action_batch = torch.tensor(batch.action, dtype=torch.long, device=device).reshape(-1,1)
    reward_batch = torch.tensor(batch.reward, dtype=torch.float32, device=device)
   
    #nextS_batch  = torch.tensor(batch.next_state, dtype=torch.float32, device=device)

    qValue  = model(state_batch).gather(1, action_batch)
    #print(qValue)
    
    qValue1 = torch.zeros(batch_size, device=device)
    q_V_a   = model(non_final_next_states).max(1)[1]
    #print(q_V_a)
    #print(len(non_final_mask), len(q_V_a))
    qValue1[non_final_mask] = target_model(non_final_next_states).detach().gather(1, q_V_a.unsqueeze(1)).squeeze(1)
    #qValue1[non_final_mask] = target_model(non_final_next_states).max(1)[0].detach()

    
    expectedV = gamma*qValue1 + reward_batch
    
    loss = loss_fn(qValue, expectedV.unsqueeze(1))
    #print(loss)
    #Optimize the model
    optimizer.zero_grad()
    loss.backward()
    for param in model.parameters():
        param.grad.data.clamp_(-1,1)
    optimizer.step()
    return expectedV.unsqueeze(1) - qValue
        
    
